from VGG_Google import VGG16_1D, VGG19_1D, AlexNet_1D, GoogLeNet_1D
from ResNet import ResNet_1D
from DenseNet import DenseNet_1D
from Transformer import Transformer_1D